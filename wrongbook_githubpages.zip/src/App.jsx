import React, { useEffect, useState } from 'react';

export default function WrongQuestionsApp() {
  const STORAGE_KEY = 'wrong_questions_v1';

  const [items, setItems] = useState([]);
  const [subjectFilter, setSubjectFilter] = useState('');
  const [searchText, setSearchText] = useState('');
  const [form, setForm] = useState({
    id: null,
    question: '',
    answer: '',
    subject: '',
    topic: '',
    reason: ''
  });
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) setItems(JSON.parse(raw));
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  }, [items]);

  function resetForm() {
    setForm({ id: null, question: '', answer: '', subject: '', topic: '', reason: '' });
    setIsEditing(false);
  }

  function nextId() {
    if (items.length === 0) return 1;
    return Math.max(...items.map(i => i.id)) + 1;
  }

  function handleAddOrUpdate(e) {
    e.preventDefault();
    const payload = {
      ...form,
      question: form.question.trim(),
      answer: form.answer.trim(),
      subject: form.subject.trim() || '未分類',
      topic: form.topic.trim(),
      reason: form.reason.trim(),
    };
    if (!payload.question) return alert('請輸入題目內容');

    if (isEditing && payload.id != null) {
      setItems(prev => prev.map(it => it.id === payload.id ? { ...it, ...payload } : it));
      resetForm();
      return;
    }

    const newEntry = {
      id: nextId(),
      ...payload,
      date_added: new Date().toISOString(),
      status: '待複習',
      review_count: 0
    };
    setItems(prev => [newEntry, ...prev]);
    resetForm();
  }

  function handleEdit(item) {
    setForm({ ...item });
    setIsEditing(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function handleDelete(id) {
    if (!confirm('確定要刪除這筆錯題嗎？')) return;
    setItems(prev => prev.filter(p => p.id !== id));
  }

  function markReviewed(id) {
    setItems(prev => prev.map(p => p.id === id ? { ...p, status: '已複習', review_count: (p.review_count||0)+1 } : p));
  }

  function incrementReview(id) {
    setItems(prev => prev.map(p => p.id === id ? { ...p, review_count: (p.review_count||0)+1 } : p));
  }

  const subjects = Array.from(new Set(items.map(i => i.subject || '未分類'))).filter(Boolean).sort();

  const filtered = items.filter(i => {
    if (subjectFilter && i.subject !== subjectFilter) return false;
    if (!searchText) return true;
    const s = searchText.toLowerCase();
    return (i.question || '').toLowerCase().includes(s) ||
           (i.answer || '').toLowerCase().includes(s) ||
           (i.topic || '').toLowerCase().includes(s) ||
           (i.reason || '').toLowerCase().includes(s);
  });

  return <div className="max-w-5xl mx-auto p-6">
    <h1 className="text-2xl font-bold mb-4">錯題本 — Web 版</h1>
    <p>本專案可直接部署至 GitHub Pages / Netlify。功能完整 localStorage 錯題本。</p>
  </div>;
}
